# CyberAttacks_OrientDB

This json script will create edges between nodes that use different sources and destinations, among other things.

Start of with going to: https://github.com/Thelin90/CyberAttacks

And follow the instructions in the manual.

