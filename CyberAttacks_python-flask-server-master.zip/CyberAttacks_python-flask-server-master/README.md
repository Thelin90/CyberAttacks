Start of with going to: https://github.com/Thelin90/CyberAttacks

And follow the instructions in the manual.
